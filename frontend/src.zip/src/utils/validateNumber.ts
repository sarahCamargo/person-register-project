export const isNumber = (value:string): boolean => {
    return /^\d*$/.test(value)
}