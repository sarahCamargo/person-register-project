import { TablePagination } from "@mui/material";
import styled from "styled-components";

export const StyledPagination = styled(TablePagination)`
  display: flex !important;
  justify-content: center;
  margin-top: 10px;
  width: 100%;
  padding: 0;

  ${({ theme }) => theme.breakpoints.down('sm')} {
    .MuiTablePagination-selectLabel {
      font-size: 10px;
    }

    .MuiTablePagination-select {
      font-size: 10px;
    }

    .MuiTablePagination-displayedRows {
      font-size: 10px;
    }
  }
`;