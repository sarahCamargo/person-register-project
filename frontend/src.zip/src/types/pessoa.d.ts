export interface Pessoa {
    id: string;
    nome: string;
    telefone: string;
    cpf: string;
    cep: string;
    logradouro:string;
    municipio: string;
    estado: string;
    bairro: string;
    numero: string;
    complemento: string;
  }